import React from 'react'
import './head.css'

function Footer(){
    return(
        <div className='row footer'>
                    <div className='col-sm-12'>
                        <p className='copyright'>All rights reserved By Dream Courses.</p>
                    </div>
                </div>
    )
}
export default Footer