import React from 'react'
import Header from './Header.js'
import Form from './Form.js'
import Footer from './Footer.js'


function Registration(){
    return(
    <div>
    <Header />
    <Form />
    <Footer />
    </div>
    )
}
export default Registration