import React from 'react'
import './head.css'

function Form(){
    return(
        <div className='row registration'>
            <div className='col-sm-12 forms'>
            <form name = "myForm" onsubmit = "return(validate(this));">
		<label>Name:</label>
		<input type="text" name="name" required /><br/>
		<label>Course</label>
		<select required>
			<option>AWS</option>
			<option>HTML</option>
			<option>CSS</option>
			<option>JavaScript</option>
			<option>React.js</option>
			<option>Node.js</option>
		</select><br/>
		<label>Email:</label>
		<input type="email" name="email" required /><br/>
		<input type="radio" name="join" />Join Immediately
		<input type="radio" name="join" />Join later <br/>
		<div id="valid"></div>
		<input type="checkbox" name="checkbox" />Subscribe to our News<br/>
		<textarea name="notes" rows="10" cols="30" placeholder="Notes" required></textarea><br/>
		<button type="submit" value="submit">Submit</button>
	</form>
    </div>
    </div>
    )
}
export default Form